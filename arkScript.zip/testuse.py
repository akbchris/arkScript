import pyautogui
print(pyautogui.locateOnScreen('OK.png'))
